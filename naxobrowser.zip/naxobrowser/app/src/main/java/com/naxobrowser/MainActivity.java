package com.naxobrowser;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebResourceError;
import android.webkit.SslErrorHandler;
import android.webkit.JavascriptInterface;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import android.webkit.CookieManager;

public class MainActivity extends AppCompatActivity implements VideoDetector.VideoDetectionListener {

    private static final String TAG = "MainActivity";
    
    private WebView webView;
    private EditText urlEditText;
    private ImageView backButton, forwardButton, refreshButton, homeButton;
    private ImageView lockIcon, braveShieldIcon, menuIcon, videoDetectionButton;
    private ProgressBar progressBar;
    private VideoDetector videoDetector;
    private boolean hasDetectedVideos = false;
    private Handler detectionHandler = new Handler();
    
    private ActivityResultLauncher<Intent> cookieActivityLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_2);

        initializeViews();
        setupActivityLaunchers();
        setupWebView();
        setupVideoDetection();
        setupButtonListeners();
        setupAddressBar();
        
        loadInitialPage();
    }

    private void initializeViews() {
        webView = findViewById(R.id.webView);
        urlEditText = findViewById(R.id.urlEditText);
        progressBar = findViewById(R.id.progressBar);
        lockIcon = findViewById(R.id.lockIcon);
        braveShieldIcon = findViewById(R.id.braveShieldIcon);
        menuIcon = findViewById(R.id.menuIcon);
        backButton = findViewById(R.id.backButton);
        forwardButton = findViewById(R.id.forwardButton);
        refreshButton = findViewById(R.id.refreshButton);
        homeButton = findViewById(R.id.homeButton);
        
        videoDetectionButton = findViewById(R.id.videoDetectionButton);
        if (videoDetectionButton != null) {
            videoDetectionButton.setColorFilter(Color.GRAY);
        }
    }

    private void setupActivityLaunchers() {
        cookieActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        String reloadUrl = result.getData().getStringExtra("reload_url");
                        if (reloadUrl != null && !reloadUrl.isEmpty()) {
                            // Verify cookies before reloading
                            verifyCookiesForUrl(reloadUrl);
                            
                            // Clear cache and reload
                            webView.clearCache(true);
                            webView.loadUrl(reloadUrl);
                            showToast("Cookies imported. Reloading page...");
                        }
                    }
                });
    }
    
    private void verifyCookiesForUrl(String url) {
        try {
            CookieManager cookieManager = CookieManager.getInstance();
            String cookies = cookieManager.getCookie(url);
            Log.d(TAG, "=== COOKIE VERIFICATION ===");
            Log.d(TAG, "URL: " + url);
            Log.d(TAG, "Cookies: " + (cookies != null ? cookies : "null"));
            
            if (cookies != null && !cookies.isEmpty()) {
                String[] cookieArray = cookies.split("; ");
                Log.d(TAG, "Total cookies for " + url + ": " + cookieArray.length);
                for (String cookie : cookieArray) {
                    Log.d(TAG, "  - " + cookie);
                }
            } else {
                Log.w(TAG, "No cookies found for " + url);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error verifying cookies: " + e.getMessage());
        }
    }

    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        
        // Basic settings
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        
        // Cookie settings - IMPORTANT for cookie functionality
        webSettings.setSaveFormData(true);
        webSettings.setSavePassword(true);
        
        // Security and access settings
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        
        // Media settings - IMPORTANT for video detection
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        
        // Zoom settings
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportZoom(true);
        
        // Enhanced User Agent for better compatibility
        String userAgent = "Mozilla/5.0 (Linux; Android 12; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 NaxoBrowser/1.0";
        webSettings.setUserAgentString(userAgent);

        // Enable cookies explicitly
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        setupWebViewClient();
        setupWebChromeClient();
    }

    private void setupWebViewClient() {
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.d(TAG, "📄 Page started loading: " + url);
                
                // Check cookies being sent with this request
                try {
                    CookieManager cookieManager = CookieManager.getInstance();
                    String cookies = cookieManager.getCookie(url);
                    if (cookies != null && !cookies.isEmpty()) {
                        Log.d(TAG, "🍪 Cookies being sent with request: " + cookies);
                    } else {
                        Log.d(TAG, "🍪 No cookies being sent with request");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error checking cookies for request: " + e.getMessage());
                }
                
                urlEditText.setText(url);
                updateLockIcon(url);
                progressBar.setVisibility(View.VISIBLE);
                
                // Clear previous videos and reset detection
                VideoManager.getInstance().clearAllVideos();
                resetVideoDetection();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "✅ Page finished loading: " + url);
                updateNavigationButtons();
                progressBar.setVisibility(View.GONE);
                
                // Multiple injection attempts with different delays
                injectVideoDetectionScript();
                
                // Facebook specific detection
                if (url.contains("facebook.com") || url.contains("fb.com")) {
                    injectFacebookSpecificDetection();
                }
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                super.onPageCommitVisible(view, url);
                Log.d(TAG, "👁️ Page visible: " + url);
                // Additional detection when page becomes visible
                detectionHandler.postDelayed(() -> injectVideoDetectionScript(), 1500);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                
                // Log all requests to find video URLs
                if (isPotentialVideoUrl(url)) {
                    Log.d(TAG, "🌐 Intercepted potential video: " + url);
                    
                    runOnUiThread(() -> {
                        VideoDetector.VideoInfo videoInfo = new VideoDetector.VideoInfo();
                        videoInfo.url = url;
                        videoInfo.format = detectFormat(url);
                        videoInfo.title = "Intercepted Video";
                        videoInfo.pageUrl = view.getUrl();
                        onVideoDetected(videoInfo);
                    });
                }
                
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed(); // Continue despite SSL errors
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                Log.e(TAG, "WebView error: " + error.getDescription());
                super.onReceivedError(view, request, error);
            }
        });
    }

    private void setupWebChromeClient() {
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    progressBar.setVisibility(View.GONE);
                    // Final detection attempt when page is fully loaded
                    detectionHandler.postDelayed(() -> {
                        injectVideoDetectionScript();
                        performManualVideoScan();
                    }, 2000);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            // Fix WebChromeClient.onConsoleMessage to return boolean
            @Override
            public boolean onConsoleMessage(android.webkit.ConsoleMessage consoleMessage) {
                Log.d(TAG, "🖥️ Console: " + consoleMessage.message());
                return super.onConsoleMessage(consoleMessage);
            }
        });
    }

    private void setupVideoDetection() {
        videoDetector = new VideoDetector(this, webView);
        videoDetector.setVideoDetectionListener(this);
    }

    private void setupButtonListeners() {
        backButton.setOnClickListener(v -> { 
            if (webView.canGoBack()) webView.goBack(); 
        });
        forwardButton.setOnClickListener(v -> { 
            if (webView.canGoForward()) webView.goForward(); 
        });
        refreshButton.setOnClickListener(v -> { 
            VideoManager.getInstance().clearAllVideos();
            resetVideoDetection();
            webView.reload(); 
        });
        homeButton.setOnClickListener(v -> loadUrl("https://www.google.com"));
        braveShieldIcon.setOnClickListener(v -> showToast("Shield Protection Active"));
        menuIcon.setOnClickListener(this::showMenu);
        
        if (videoDetectionButton != null) {
            videoDetectionButton.setOnClickListener(v -> {
                Intent intent = new Intent(this, VideoListActivity.class);
                startActivity(intent);
            });
        }
    }

    private void setupAddressBar() {
        urlEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                String input = urlEditText.getText().toString().trim();
                if (!input.isEmpty()) {
                    hideKeyboard();
                    urlEditText.clearFocus();
                    handleUserInput(input);
                }
                return true;
            }
            return false;
        });
    }

    private void handleUserInput(String input) {
        if (Patterns.WEB_URL.matcher(input).matches()) {
            loadUrl(normalizeUrl(input));
        } else {
            performSearch(input);
        }
    }

    private String normalizeUrl(String url) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            return "https://" + url;
        }
        return url;
    }

    private void loadUrl(String url) {
        if (!isNetworkAvailable()) {
            showToast("No internet connection");
            return;
        }
        Log.d(TAG, "🌐 Loading URL: " + url);
        webView.loadUrl(url);
    }

    private void performSearch(String query) {
        try {
            String searchUrl = "https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8");
            loadUrl(searchUrl);
        } catch (Exception e) {
            showToast("Error in search");
            Log.e(TAG, "Search error", e);
        }
    }

    private void injectVideoDetectionScript() {
        if (videoDetector != null) {
            Log.d(TAG, "💉 Injecting video detection script...");
            
            // Multiple injection attempts with different delays
            detectionHandler.post(() -> videoDetector.setupVideoDetection());
            detectionHandler.postDelayed(() -> videoDetector.setupVideoDetection(), 1000);
            detectionHandler.postDelayed(() -> videoDetector.setupVideoDetection(), 3000);
            detectionHandler.postDelayed(() -> videoDetector.setupVideoDetection(), 5000);
        }
    }

    private void injectFacebookSpecificDetection() {
        Log.d(TAG, "📘 Injecting Facebook-specific detection...");
        
        String facebookScript = "javascript:(function() {" +
            "console.log('📘 Facebook video detection started');" +
            
            // Monitor Facebook's video player
            "const checkFbVideos = () => {" +
            "  const videoSelectors = [" +
            "    'video[src]'," +
            "    'video[data-video-url]'," +
            "    '[data-video-id] video'," +
            "    '.fbStoryAttachmentImage video'," +
            "    '[role=\"presentation\"] video'," +
            "    '.scaledImageFitWidth video'" +
            "  ];" +
            "  " +
            "  videoSelectors.forEach(selector => {" +
            "    try {" +
            "      const videos = document.querySelectorAll(selector);" +
            "      videos.forEach(video => {" +
            "        if (video.src && video.src !== '') {" +
            "          console.log('📱 FB Video found:', video.src);" +
            "          VideoDetectorAndroid.onVideoUrlDetected(video.src, 'FB_VIDEO', video.src);" +
            "        }" +
            "        if (video.currentSrc && video.currentSrc !== ''
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)